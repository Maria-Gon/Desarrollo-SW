import { Student } from './student.js';
export const dataStudents = [
    new Student("Código","202012265"),
    new Student("Cédula","1007812365"),
    new Student("Edad","18 años"),
    new Student("Dirección","Calle 145 #57 a 23"),
    new Student("Telefono","3103005610")
]