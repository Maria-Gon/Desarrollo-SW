export class Student {
    cadena: string;
    valor: string;

    constructor(cadena: string, valor:string) {
        this.cadena = cadena;
        this.valor = valor;
    }
}