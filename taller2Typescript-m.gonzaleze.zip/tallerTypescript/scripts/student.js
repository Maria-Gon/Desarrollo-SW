var Student = /** @class */ (function () {
    function Student(cadena, valor) {
        this.cadena = cadena;
        this.valor = valor;
    }
    return Student;
}());
export { Student };
