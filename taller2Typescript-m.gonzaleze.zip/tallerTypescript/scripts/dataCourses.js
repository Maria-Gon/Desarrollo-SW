import { Course } from './course.js';
export var dataCourses = [
    new Course("Desarrollo de SW en equipo", "Ruby Casallas", 3),
    new Course("Volleyball arena", "Rafael Noriega", 1),
    new Course("Softbol", "Jose Aguirre", 1),
    new Course("Diseño y analisis de algoritmos", "Ruben Manrique", 3),
    new Course("Sistemas Transaccionales", "Claudia Jimenez", 3),
    new Course("TI en organizaciones", "Disney Rubiano", 3),
    new Course("Biologia celular-laboratorio", "Adriana Rodriguez", 0),
    new Course("Robots del hoy y del mañana", "Carlos Rodriguez", 2),
    new Course("TI en organizaciones", "Disney Rubiano", 3)
];
